package com.example.gestionreparacionesapp.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.gestionreparacionesapp.R;
import com.example.gestionreparacionesapp.ui.clientes.ListaClientesActivity;
import com.example.gestionreparacionesapp.ui.productos.ListaProductosActivity;
import com.example.gestionreparacionesapp.ui.reparaciones.ListaReparacionesActivity;
import com.example.gestionreparacionesapp.ui.ventas.ListaVentasActivity;

import com.google.android.material.card.MaterialCardView;

public class DashboardFragment extends Fragment {

    private MaterialCardView cardClientes, cardProductos, cardReparaciones, cardVentas, cardConfig, cardLogout;

    public DashboardFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        cardClientes = view.findViewById(R.id.cardClientes);
        cardProductos = view.findViewById(R.id.cardProductos);
        cardReparaciones = view.findViewById(R.id.cardReparaciones);
        cardVentas = view.findViewById(R.id.cardVentas);
        cardConfig = view.findViewById(R.id.cardConfig);
        cardLogout = view.findViewById(R.id.cardLogout);

        setupListeners();
    }

    private void setupListeners() {

        cardClientes.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ListaClientesActivity.class)));

        cardProductos.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ListaProductosActivity.class)));

        cardReparaciones.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ListaReparacionesActivity.class)));

        cardVentas.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ListaVentasActivity.class)));

        cardConfig.setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ConfiguracionActivity.class)));

        cardLogout.setOnClickListener(v -> {
            requireActivity().finishAffinity();
            startActivity(new Intent(getActivity(), com.example.gestionreparacionesapp.ui.login.LoginActivity.class));
        });
    }
}
